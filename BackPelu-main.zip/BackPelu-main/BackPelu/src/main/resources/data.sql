INSERT IGNORE INTO erabiltzaileak (username, pasahitza, rola, sortze_data, eguneratze_data)
VALUES
    ('ikasle', '123', 'IK', NOW(), NOW()),
    ('irakasle', '123', 'IR', NOW(), NOW());
